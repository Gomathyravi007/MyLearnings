insert into todo(ID, USER_NAME, DESCRIPTION, TARGET_DATE, DONE)
values(1001,'gom','Learn Aws',CURRENT_DATE, false);

insert into todo(ID, USER_NAME, DESCRIPTION, TARGET_DATE, DONE)
values(1002,'gom','Learn Azure',CURRENT_DATE, false);

insert into todo(ID, USER_NAME, DESCRIPTION, TARGET_DATE, DONE)
values(1003,'gom','Learn java',CURRENT_DATE, false);

insert into todo(ID, USER_NAME, DESCRIPTION, TARGET_DATE, DONE)
values(1004,'gom','Learn anything',CURRENT_DATE, false);

