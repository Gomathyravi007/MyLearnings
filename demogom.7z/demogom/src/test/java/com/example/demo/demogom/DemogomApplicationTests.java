package com.example.demo.demogom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemogomApplicationTests {

	@Test
	void contextLoads() {
	}

}
